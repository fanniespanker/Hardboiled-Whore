# CNML Poem DSL (Subspec)

## Core Model
- Layout is span-driven
- Lines define vertical stacking only
- Spans own all horizontal whitespace

## Span Syntax
{{#name [:role] :: content}}

## Anchors
{{@name}}

Implicit:
- span.left
- span.right
- span.center

## Alignment
<  left-align to anchor
>  right-align to anchor
|  center on anchor

## Expressions
< anchor + expression

Rules:
- exactly one anchor
- anchor must be first
- DAG only

## Whitespace
- preserved inside spans
- no implicit spacing between spans
- raw text = implicit span

## Geometry
- includes whitespace
- geometry refs are anchors

## Layout
- attachment-based
- no global coordinate system
